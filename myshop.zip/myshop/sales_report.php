<?php
session_start();
include 'db.php';

// Cek apakah user sudah login sebagai admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

$sales_summary = [];
$product_details = [];

$start_date = '';
$end_date = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];

    if (!empty($start_date) && !empty($end_date)) {
        // Ambil total pendapatan per hari
        try {
            $stmt = $conn->prepare("
                SELECT 
                    DATE(order_date) AS order_date,
                    COUNT(*) AS total_orders,
                    SUM(total_amount) AS total_sales
                FROM orders
                WHERE DATE(order_date) BETWEEN :start_date AND :end_date
                GROUP BY DATE(order_date)
            ");
            $stmt->bindParam(':start_date', $start_date);
            $stmt->bindParam(':end_date', $end_date);
            $stmt->execute();
            $sales_summary = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            die("Error: " . $e->getMessage());
        }

        // Ambil detail produk terjual
        try {
            $stmt = $conn->prepare("
                SELECT 
                    p.name AS product_name,
                    od.quantity AS total_quantity,
                    od.price AS unit_price,
                    (od.quantity * od.price) AS total_revenue
                FROM order_details od
                JOIN products p ON od.product_id = p.id
                JOIN orders o ON od.order_id = o.id
                WHERE DATE(o.order_date) BETWEEN :start_date AND :end_date
            ");
            $stmt->bindParam(':start_date', $start_date);
            $stmt->bindParam(':end_date', $end_date);
            $stmt->execute();
            $product_details = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            die("Error: " . $e->getMessage());
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Penjualan - Fashion Store</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Laporan Penjualan</h1>

        <!-- Tombol Back -->
        <div class="mb-3 text-start">
            <a href="admin_dashboard.php" class="btn btn-secondary">Back to Admin Dashboard</a>
        </div>

        <!-- Form Filter Tanggal -->
        <form method="POST" class="mb-4">
            <div class="row">
                <div class="col-md-6">
                    <label for="start_date" class="form-label">Tanggal Mulai:</label>
                    <input type="date" class="form-control" name="start_date" value="<?php echo htmlspecialchars($start_date); ?>" required>
                </div>
                <div class="col-md-6">
                    <label for="end_date" class="form-label">Tanggal Akhir:</label>
                    <input type="date" class="form-control" name="end_date" value="<?php echo htmlspecialchars($end_date); ?>" required>
                </div>
            </div>
            <button type="submit" class="btn btn-primary mt-3">Tampilkan Laporan</button>
        </form>
        <form method="POST" action="export_sales_report.php" class="mb-3">
    <input type="hidden" name="start_date" value="<?php echo htmlspecialchars($start_date); ?>">
    <input type="hidden" name="end_date" value="<?php echo htmlspecialchars($end_date); ?>">
    <button type="submit" class="btn btn-success">Export to CSV</button>
</form>

        <!-- Tabel Ringkasan Penjualan -->
        <?php if (!empty($sales_summary)): ?>
            <h3 class="mt-4">Ringkasan Penjualan</h3>
            <table class="table table-bordered table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>Tanggal</th>
                        <th>Total Pesanan</th>
                        <th>Total Pendapatan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($sales_summary as $summary): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($summary['order_date']); ?></td>
                            <td><?php echo htmlspecialchars($summary['total_orders']); ?></td>
                            <td>Rp <?php echo number_format($summary['total_sales'], 0, ',', '.'); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <!-- Tabel Detail Produk Terjual -->
        <?php if (!empty($product_details)): ?>
            <h3 class="mt-4">Detail Produk Terjual</h3>
            <table class="table table-bordered table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>Nama Produk</th>
                        <th>Jumlah Terjual</th>
                        <th>Harga Satuan</th>
                        <th>Total Pendapatan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($product_details as $detail): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($detail['product_name']); ?></td>
                            <td><?php echo htmlspecialchars($detail['total_quantity']); ?></td>
                            <td>Rp <?php echo number_format($detail['unit_price'], 0, ',', '.'); ?></td>
                            <td>Rp <?php echo number_format($detail['total_revenue'], 0, ',', '.'); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</body>
</html>