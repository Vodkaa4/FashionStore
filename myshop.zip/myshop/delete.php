<?php
session_start();
include 'db.php';

// Redirect jika belum login atau bukan admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

if (isset($_GET['id'])) {
    $product_id = intval($_GET['id']);

    try {
        // Mulai transaksi
        $conn->beginTransaction();

        // Hapus data di tabel order_items yang nyangkut ke produk
        $stmt = $conn->prepare("DELETE FROM order_items WHERE product_id = :product_id");
        $stmt->bindParam(':product_id', $product_id, PDO::PARAM_INT);
        $stmt->execute();

        // Hapus data di tabel wishlist yang nyangkut ke produk
        $stmt = $conn->prepare("DELETE FROM wishlist WHERE product_id = :product_id");
        $stmt->bindParam(':product_id', $product_id, PDO::PARAM_INT);
        $stmt->execute();

        // Hapus data di tabel cart yang nyangkut ke produk
        $stmt = $conn->prepare("DELETE FROM cart WHERE product_id = :product_id");
        $stmt->bindParam(':product_id', $product_id, PDO::PARAM_INT);
        $stmt->execute();

        // Hapus produk dari tabel products
        $stmt = $conn->prepare("DELETE FROM products WHERE id = :product_id");
        $stmt->bindParam(':product_id', $product_id, PDO::PARAM_INT);
        $stmt->execute();

        // Commit transaksi
        $conn->commit();

        header("Location: index.php");
        exit;
    } catch (PDOException $e) {
        // Rollback transaksi kalo ada error
        $conn->rollBack();
        die("Error: " . $e->getMessage());
    }
} else {
    die("ID produk tidak valid.");
}
?>