<?php
$host = 'localhost';
$dbname = 'fashion_store';
$username = 'root'; // Ganti sesuai username MySQL lo
$password = ''; // Ganti sesuai password MySQL lo

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Koneksi gagal: " . $e->getMessage();
}
?>