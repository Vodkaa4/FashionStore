<?php
session_start();
include 'db.php';

// Cek apakah user sudah login sebagai admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

try {
    // Ambil semua promo
    $stmt = $conn->prepare("SELECT * FROM promos ORDER BY valid_from DESC");
    $stmt->execute();
    $promos = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Promo - Fashion Store</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Kelola Promo</h1>

        <!-- Tombol Back dan Tambah Promo Baru -->
        <div class="d-flex justify-content-between mb-3">
            <a href="admin_dashboard.php" class="btn btn-secondary">Kembali</a>
            <a href="add_promo.php" class="btn btn-primary">Tambah Promo Baru</a>
        </div>

        <table class="table table-bordered table-hover">
            <thead class="table-dark">
                <tr>
                    <th>Kode Promo</th>
                    <th>Deskripsi</th>
                    <th>Diskon (%)</th>
                    <th>Berlaku Dari</th>
                    <th>Berlaku Sampai</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($promos)): ?>
                    <?php foreach ($promos as $promo): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($promo['code']); ?></td>
                            <td><?php echo htmlspecialchars($promo['description']); ?></td>
                            <td><?php echo htmlspecialchars($promo['discount']); ?>%</td>
                            <td><?php echo htmlspecialchars($promo['valid_from']); ?></td>
                            <td><?php echo htmlspecialchars($promo['valid_to']); ?></td>
                            <td>
                                <a href="edit_promo.php?id=<?php echo htmlspecialchars($promo['id']); ?>" class="btn btn-warning btn-sm">Edit</a>
                                <a href="delete_promo.php?id=<?php echo htmlspecialchars($promo['id']); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin mau hapus promo ini?')">Hapus</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="text-center">Tidak ada promo tersedia.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>