<?php
session_start();
include 'db.php';

// Redirect jika belum login atau bukan admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

$order_id = isset($_GET['id']) ? intval($_GET['id']) : null;

if (!$order_id) {
    die("ID pesanan tidak valid.");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['status'])) {
    $status = trim($_POST['status']);

    try {
        // Update status pesanan
        $stmt = $conn->prepare("UPDATE orders SET status = :status WHERE id = :order_id");
        $stmt->bindParam(':status', $status, PDO::PARAM_STR);
        $stmt->bindParam(':order_id', $order_id, PDO::PARAM_INT);
        $stmt->execute();

        // Debugging: Pastikan query berhasil
        if ($stmt->rowCount() > 0) {
            // Redirect balik ke Admin Dashboard
            header("Location: admin_dashboard.php");
            exit;
        } else {
            die("Gagal memperbarui status pesanan.");
        }
    } catch (PDOException $e) {
        die("Error: " . $e->getMessage());
    }
}

try {
    // Ambil data pesanan berdasarkan ID
    $stmt = $conn->prepare("SELECT * FROM orders WHERE id = :order_id");
    $stmt->bindParam(':order_id', $order_id, PDO::PARAM_INT);
    $stmt->execute();
    $order = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$order) {
        die("Pesanan tidak ditemukan.");
    }
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Pesanan - Fashion Store</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Update Status Pesanan</h1>

        <!-- Form Update Status -->
        <form method="POST">
            <div class="mb-3">
                <label for="status" class="form-label">Status Pesanan</label>
                <select class="form-select" id="status" name="status" required>
                    <option value="" disabled>Pilih Status</option>
                    <option value="Pending" <?php echo ($order['status'] == 'Pending') ? 'selected' : ''; ?>>Pending</option>
                    <option value="Dikirim" <?php echo ($order['status'] == 'Dikirim') ? 'selected' : ''; ?>>Dikirim</option>
                    <option value="Selesai" <?php echo ($order['status'] == 'Selesai') ? 'selected' : ''; ?>>Selesai</option>
                    <option value="Dibatalkan" <?php echo ($order['status'] == 'Dibatalkan') ? 'selected' : ''; ?>>Dibatalkan</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
            <a href="admin_dashboard.php" class="btn btn-secondary">Kembali</a>
        </form>
    </div>
</body>
</html>