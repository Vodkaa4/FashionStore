<?php
session_start();
include 'db.php';

// Redirect jika belum login atau bukan admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

try {
    // Query untuk mengambil semua data pesanan
    $stmt = $conn->prepare("SELECT * FROM orders ORDER BY order_date DESC");
    $stmt->execute();
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}

// Set header buat download file CSV
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="orders.csv"');

// Buka output stream
$output = fopen('php://output', 'w');

// Tulis header kolom
fputcsv($output, ['ID Pesanan', 'Tanggal Pesanan', 'Total Harga', 'Status']);

// Tulis data pesanan
foreach ($orders as $order) {
    fputcsv($output, [
        $order['id'],
        $order['order_date'],
        $order['total_amount'],
        $order['status']
    ]);
}

// Tutup output stream
fclose($output);
exit;
?>