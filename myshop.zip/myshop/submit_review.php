<?php
session_start();
include 'db.php';

// Cek apakah user sudah login sebagai customer
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'customer') {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$product_id = $_POST['product_id'] ?? null;
$rating = $_POST['rating'] ?? null;
$comment = trim($_POST['comment']);

if (!$product_id || !$rating || empty($comment)) {
    die("Semua field wajib diisi.");
}

try {
    // Simpan review ke database
    $stmt = $conn->prepare("INSERT INTO reviews (user_id, product_id, rating, comment) VALUES (:user_id, :product_id, :rating, :comment)");
    $stmt->bindParam(':user_id', $user_id);
    $stmt->bindParam(':product_id', $product_id);
    $stmt->bindParam(':rating', $rating);
    $stmt->bindParam(':comment', $comment);

    if ($stmt->execute()) {
        header("Location: product_detail.php?id=$product_id&success=Review berhasil dikirim!");
        exit;
    } else {
        die("Gagal mengirim review.");
    }
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>