<?php
session_start();
include 'db.php';

// Redirect jika belum login atau bukan customer
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'customer') {
    header("Location: login.php");
    exit;
}

try {
    // Ambil semua produk dari database
    $stmt = $conn->prepare("SELECT * FROM products ORDER BY id DESC");
    $stmt->execute();
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Produk - Fashion Store</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Daftar Produk</h1>

        <!-- Tombol Back -->
        <div class="mb-3">
            <a href="customer_dashboard.php" class="btn btn-secondary">Kembali</a>
        </div>

        <div class="row">
            <?php if (!empty($products)): ?>
                <?php foreach ($products as $product): ?>
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <img src="<?php echo htmlspecialchars($product['image']); ?>" class="card-img-top" alt="Gambar Produk" style="height: 200px; object-fit: cover;">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($product['name']); ?></h5>
                                <p class="card-text"><?php echo htmlspecialchars($product['description']); ?></p>
                                <p class="card-text"><strong>Harga:</strong> Rp <?php echo number_format($product['price'], 0, ',', '.'); ?></p>
                                <p class="card-text"><strong>Stok:</strong> <?php echo htmlspecialchars($product['stock']); ?></p>
                                <p class="card-text"><strong>Ukuran:</strong> <?php echo htmlspecialchars($product['size']); ?></p>
                                <p class="card-text"><strong>Warna:</strong> <?php echo htmlspecialchars($product['color']); ?></p>
                                <div class="d-flex gap-2">
                                    <a href="add_to_wishlist.php?id=<?php echo htmlspecialchars($product['id']); ?>" class="btn btn-danger btn-sm">
                                        <i class="fas fa-heart me-1"></i> Wishlist
                                    </a>
                                    <a href="add_to_cart.php?id=<?php echo htmlspecialchars($product['id']); ?>" class="btn btn-primary btn-sm">
                                        <i class="fas fa-cart-plus me-1"></i> Keranjang
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="col-12 text-center">
                    <p>Tidak ada produk tersedia.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>