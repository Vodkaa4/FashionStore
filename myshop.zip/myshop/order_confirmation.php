<?php
session_start();
include 'db.php';

// Redirect jika belum login atau bukan customer
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'customer') {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    // Ambil data pesanan terbaru
    $stmt = $conn->prepare("
        SELECT o.id AS order_id, o.total_amount, o.status, o.order_date
        FROM orders o
        WHERE o.user_id = :user_id
        ORDER BY o.order_date DESC
        LIMIT 1
    ");
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $order = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$order) {
        die("Pesanan tidak ditemukan.");
    }
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Konfirmasi Pesanan - Fashion Store</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Konfirmasi Pesanan</h1>

        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Pesanan Berhasil Dibuat!</h5>
                <p><strong>ID Pesanan:</strong> <?php echo htmlspecialchars($order['order_id']); ?></p>
                <p><strong>Total Harga:</strong> Rp <?php echo number_format($order['total_amount'], 0, ',', '.'); ?></p>
                <p><strong>Status:</strong> <?php echo htmlspecialchars($order['status']); ?></p>
                <p><strong>Tanggal Pesanan:</strong> <?php echo htmlspecialchars($order['order_date']); ?></p>
                <a href="customer_dashboard.php" class="btn btn-primary">Kembali ke Dashboard</a>
            </div>
        </div>
    </div>
</body>
</html>