<?php
session_start();
include 'db.php';

// Cek apakah user sudah login sebagai admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

$product_id = $_GET['id'] ?? null;

if (!$product_id) {
    die("ID produk tidak ditemukan.");
}

// Ambil data produk dari database
$stmt = $conn->prepare("SELECT * FROM products WHERE id = :id");
$stmt->bindParam(':id', $product_id);
$stmt->execute();
$product = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$product) {
    die("Produk tidak ditemukan.");
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $category_id = $_POST['category_id'];
    $size = trim($_POST['size']);
    $color = trim($_POST['color']);

    // Validasi input
    if (empty($name) || empty($description) || empty($price) || empty($stock)) {
        $error = "Semua field wajib diisi.";
    } else {
        // Upload gambar baru (kalau ada)
        $image = $product['image']; // Default gambar lama
        if ($_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $target_dir = "uploads/";
            if (!is_dir($target_dir)) {
                mkdir($target_dir, 0777, true); // Buat folder uploads kalau belum ada
            }
            $target_file = $target_dir . basename($_FILES["image"]["name"]);
            move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);
            $image = $target_file;
        }

        // Update data di database
        try {
            $stmt = $conn->prepare("UPDATE products SET name = :name, description = :description, price = :price, stock = :stock, category_id = :category_id, size = :size, color = :color, image = :image WHERE id = :id");
            $stmt->bindParam(':name', $name);
            $stmt->bindParam(':description', $description);
            $stmt->bindParam(':price', $price);
            $stmt->bindParam(':stock', $stock);
            $stmt->bindParam(':category_id', $category_id);
            $stmt->bindParam(':size', $size);
            $stmt->bindParam(':color', $color);
            $stmt->bindParam(':image', $image);
            $stmt->bindParam(':id', $product_id);

            if ($stmt->execute()) {
                $success = "Produk berhasil diperbarui!";
            } else {
                $error = "Gagal memperbarui produk.";
            }
        } catch (PDOException $e) {
            $error = "Error: " . $e->getMessage();
        }
    }
}

// Ambil semua kategori buat dropdown
$category_stmt = $conn->prepare("SELECT * FROM categories");
$category_stmt->execute();
$categories = $category_stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Produk</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Edit Produk</h1>

        <!-- Tombol Kembali -->
        <a href="index.php?id=<?php echo $product_id; ?>" class="btn btn-secondary mb-3">
            ← Kembali ke Daftar Produk
        </a>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <form method="POST" action="" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="name" class="form-label">Nama Produk:</label>
                <input type="text" class="form-control" name="name" value="<?php echo htmlspecialchars($product['name']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="description" class="form-label">Deskripsi:</label>
                <textarea class="form-control" name="description" required><?php echo htmlspecialchars($product['description']); ?></textarea>
            </div>
            <div class="mb-3">
                <label for="price" class="form-label">Harga:</label>
                <input type="number" step="0.01" class="form-control" name="price" value="<?php echo htmlspecialchars($product['price']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="stock" class="form-label">Stok:</label>
                <input type="number" class="form-control" name="stock" value="<?php echo htmlspecialchars($product['stock']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="category_id" class="form-label">Kategori:</label>
                <select class="form-select" name="category_id" required>
                    <option value="">Pilih Kategori</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?php echo $category['id']; ?>" <?php echo ($category['id'] == $product['category_id']) ? 'selected' : ''; ?>>
                            <?php echo $category['name']; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="size" class="form-label">Ukuran:</label>
                <input type="text" class="form-control" name="size" value="<?php echo htmlspecialchars($product['size']); ?>" placeholder="S, M, L, XL">
            </div>
            <div class="mb-3">
                <label for="color" class="form-label">Warna:</label>
                <input type="text" class="form-control" name="color" value="<?php echo htmlspecialchars($product['color']); ?>" placeholder="Hitam, Putih, Merah">
            </div>
            <div class="mb-3">
                <label for="image" class="form-label">Gambar Saat Ini:</label>
                <br>
                <img src="<?php echo htmlspecialchars($product['image']); ?>" alt="Gambar Produk" width="100">
            </div>
            <div class="mb-3">
                <label for="image" class="form-label">Upload Gambar Baru:</label>
                <input type="file" class="form-control" name="image" accept="image/*">
            </div>
            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
        </form>
    </div>
</body>
</html>