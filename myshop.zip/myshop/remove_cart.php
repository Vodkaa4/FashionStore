<?php
session_start();
include 'db.php';

// Redirect jika belum login atau bukan customer
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'customer') {
    header("Location: login.php");
    exit;
}

if (isset($_GET['id'])) {
    $cart_id = intval($_GET['id']); // Pastiin input aman
    $user_id = $_SESSION['user_id'];

    try {
        // Cek apakah item keranjang ada dan milik user yang login
        $stmt = $conn->prepare("SELECT * FROM cart WHERE id = :cart_id AND user_id = :user_id");
        $stmt->bindParam(':cart_id', $cart_id, PDO::PARAM_INT);
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->execute();
        $cart_item = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($cart_item) {
            // Hapus item dari keranjang
            $delete_stmt = $conn->prepare("DELETE FROM cart WHERE id = :cart_id AND user_id = :user_id");
            $delete_stmt->bindParam(':cart_id', $cart_id, PDO::PARAM_INT);
            $delete_stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            $delete_stmt->execute();

            // Redirect balik ke halaman keranjang
            header("Location: cart.php");
            exit;
        } else {
            die("Item keranjang tidak ditemukan.");
        }
    } catch (PDOException $e) {
        die("Error: " . $e->getMessage());
    }
} else {
    die("ID keranjang tidak valid.");
}
?>