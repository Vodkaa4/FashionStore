<?php
session_start();
include 'db.php';

// Pastikan ID produk ada di URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Produk tidak ditemukan.");
}

$product_id = $_GET['id'];

// Ambil detail produk berdasarkan ID
try {
    $stmt = $conn->prepare("SELECT * FROM products WHERE id = :id");
    $stmt->bindParam(':id', $product_id, PDO::PARAM_INT);
    $stmt->execute();
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$product) {
        die("Produk tidak ditemukan.");
    }
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}

// Ambil review produk
try {
    $review_stmt = $conn->prepare("
        SELECT r.rating, r.comment, u.username, r.created_at
        FROM reviews r
        JOIN users u ON r.user_id = u.id
        WHERE r.product_id = :product_id
        ORDER BY r.created_at DESC
    ");
    $review_stmt->bindParam(':product_id', $product_id);
    $review_stmt->execute();
    $reviews = $review_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Produk - Fashion Store</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; }
        .btn-cart { background-color: #28a745; color: white; }
        .btn-wishlist { background-color: #dc3545; color: white; }
        .review-item { border-bottom: 1px solid #ddd; padding: 10px 0; }
    </style>
</head>
<body>
    <div class="container mt-5">
        <!-- Tombol Kembali -->
        <a href="index.php" class="btn btn-secondary mb-3">← Kembali ke Daftar Produk</a>

        <div class="row">
            <!-- Gambar Produk -->
            <div class="col-md-6">
                <img src="<?php echo htmlspecialchars($product['image']); ?>" class="img-fluid rounded" alt="Gambar Produk">
            </div>

            <!-- Detail Produk -->
            <div class="col-md-6">
                <h2><?php echo htmlspecialchars($product['name']); ?></h2>
                <p><?php echo htmlspecialchars($product['description']); ?></p>
                <h4>Rp <?php echo number_format($product['price'], 0, ',', '.'); ?></h4>
                <p><strong>Stok:</strong> <?php echo htmlspecialchars($product['stock']); ?></p>
                <p><strong>Ukuran:</strong> <?php echo htmlspecialchars($product['size']); ?></p>
                <p><strong>Warna:</strong> <?php echo htmlspecialchars($product['color']); ?></p>

                <!-- Tombol Aksi 
                <a href="add_to_cart.php?product_id=<?php echo $product['id']; ?>" class="btn btn-cart me-2">Tambah ke Keranjang</a>
                <a href="add_to_wishlist.php?product_id=<?php echo $product['id']; ?>" class="btn btn-wishlist">Tambah ke Wishlist</a>
-->
                <!-- Edit & Hapus (Hanya untuk Admin) -->
                <?php if (isset($_SESSION['user_id']) && $_SESSION['role'] == 'admin'): ?>
                    <div class="mt-3">
                       <!-- <a href="edit.php?id=<?php echo $product['id']; ?>" class="btn btn-warning me-2">Edit Produk</a> -->
                       <!-- <a href="delete_product.php?id=<?php echo $product['id']; ?>" class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus produk ini?');">Hapus Produk</a>-->
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Review Produk -->
        <div class="mt-5">
            <h3>Review Produk</h3>
            <?php if (!empty($reviews)): ?>
                <div>
                    <?php foreach ($reviews as $review): ?>
                        <div class="review-item">
                            <strong><?php echo htmlspecialchars($review['username']); ?></strong>
                            <p>Rating: <?php echo htmlspecialchars($review['rating']); ?>/5</p>
                            <p><?php echo htmlspecialchars($review['comment']); ?></p>
                            <small class="text-muted"><?php echo htmlspecialchars($review['created_at']); ?></small>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p>Belum ada review untuk produk ini.</p>
            <?php endif; ?>
        </div>

        <!-- Form Tambah Review -->
        <?php if (isset($_SESSION['user_id']) && $_SESSION['role'] == 'customer'): ?>
            <div class="mt-4">
                <h4>Tambah Review</h4>
                <form method="POST" action="submit_review.php">
                    <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                    <div class="mb-3">
                        <label for="rating" class="form-label">Rating:</label>
                        <select class="form-select" name="rating" required>
                            <option value="1">1 - Buruk</option>
                            <option value="2">2 - Kurang Memuaskan</option>
                            <option value="3">3 - Cukup</option>
                            <option value="4">4 - Baik</option>
                            <option value="5">5 - Sangat Baik</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="comment" class="form-label">Komentar:</label>
                        <textarea class="form-control" name="comment" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Kirim Review</button>
                </form>
            </div>
        <?php endif; ?>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>