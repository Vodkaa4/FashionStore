<?php
session_start();
include 'db.php';

// Cek apakah user sudah login sebagai admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

$id = $_GET['id'] ?? null;

if (!$id) {
    die("ID promo tidak ditemukan.");
}

try {
    // Hapus promo
    $stmt = $conn->prepare("DELETE FROM promos WHERE id = :id");
    $stmt->bindParam(':id', $id);

    if ($stmt->execute()) {
        header("Location: manage_promos.php?success=Promo berhasil dihapus!");
        exit;
    } else {
        die("Gagal menghapus promo.");
    }
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>