<?php
session_start();
include 'db.php';

// Redirect jika belum login atau bukan admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

try {
    // Total Pendapatan Hari Ini
    $today = date('Y-m-d');
    $stmt = $conn->prepare("SELECT SUM(total_amount) AS total_sales FROM orders WHERE DATE(order_date) = :today");
    $stmt->bindParam(':today', $today);
    $stmt->execute();
    $total_sales_today = $stmt->fetch(PDO::FETCH_ASSOC)['total_sales'];

    // Pesanan Terbaru
    $query = "SELECT * FROM orders WHERE 1=1";
    if (isset($_GET['search']) && !empty($_GET['search'])) {
        $search = "%{$_GET['search']}%";
        $query .= " AND (id LIKE :search OR status LIKE :search)";
    }
    $query .= " ORDER BY order_date DESC LIMIT 5";

    $stmt = $conn->prepare($query);
    if (isset($_GET['search']) && !empty($_GET['search'])) {
        $stmt->bindParam(':search', $search, PDO::PARAM_STR);
    }
    $stmt->execute();
    $recent_orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Grafik Penjualan Bulanan
    $stmt = $conn->prepare("
        SELECT MONTH(order_date) AS month, SUM(total_amount) AS total_sales
        FROM orders
        WHERE YEAR(order_date) = YEAR(CURDATE())
        GROUP BY MONTH(order_date)
    ");
    $stmt->execute();
    $monthly_sales = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Produk Stok Rendah
    $stmt = $conn->prepare("SELECT * FROM products WHERE stock < 10");
    $stmt->execute();
    $low_stock_products = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Fashion Store</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- Custom CSS -->
    <style>
        body { 
            background-color: #f8f9fa; 
            font-family: 'Poppins', sans-serif;
        }
        
        .sidebar { 
            background: linear-gradient(135deg, #4e73df 10%, #224abe 100%);
            height: 100vh;
            position: fixed;
            width: 250px;
            transition: all 0.3s;
            z-index: 1;
        }
        
        .sidebar .logo {
            padding: 20px 15px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .logo h4 {
            color: #fff;
            margin-bottom: 0;
        }
        
        .sidebar a { 
            text-decoration: none; 
            color: rgba(255, 255, 255, 0.8); 
            transition: all 0.3s ease;
            padding: 12px 20px;
            display: block;
            font-weight: 500;
        }
        
        .sidebar a:hover, 
        .sidebar a.active { 
            background-color: rgba(255, 255, 255, 0.1);
            color: #fff;
            border-left: 4px solid #ffffff;
        }
        
        .sidebar .fas, 
        .sidebar .fa-solid {
            width: 25px;
            text-align: center;
            margin-right: 10px;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px 30px;
            transition: all 0.3s;
        }
        
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
            border: none;
            margin-bottom: 20px;
        }
        
        .card:hover {
            transform: translateY(-5px);
        }
        
        .border-left-primary {
            border-left: 5px solid #4e73df;
        }
        
        .border-left-success {
            border-left: 5px solid #1cc88a;
        }
        
        .border-left-warning {
            border-left: 5px solid #f6c23e;
        }
        
        .border-left-danger {
            border-left: 5px solid #e74a3b;
        }
        
        .btn-primary {
            background-color: #4e73df;
            border-color: #4e73df;
        }
        
        .btn-primary:hover {
            background-color: #2e59d9;
            border-color: #2e59d9;
        }
        
        .btn-success {
            background-color: #1cc88a;
            border-color: #1cc88a;
        }
        
        .btn-success:hover {
            background-color: #17a673;
            border-color: #17a673;
        }
        
        .btn-warning {
            background-color: #f6c23e;
            border-color: #f6c23e;
            color: #fff;
        }
        
        .btn-warning:hover {
            background-color: #f4b619;
            border-color: #f4b619;
            color: #fff;
        }
        
        .table {
            border-radius: 10px;
            overflow: hidden;
        }
        
        .table thead {
            background-color: #4e73df;
            color: white;
        }
        
        .table-hover tbody tr:hover {
            background-color: #eaecf4;
        }
        
        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 500;
        }
        
        .status-pending {
            background-color: #f39c12;
            color: white;
        }
        
        .status-processing {
            background-color: #3498db;
            color: white;
        }
        
        .status-shipped {
            background-color: #2ecc71;
            color: white;
        }
        
        .status-delivered {
            background-color: #27ae60;
            color: white;
        }
        
        .status-cancelled {
            background-color: #e74c3c;
            color: white;
        }
        
        .welcome-banner {
            background: linear-gradient(135deg, #4e73df, #224abe);
            color: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .stats-card {
            text-align: center;
            padding: 20px;
        }
        
        .stats-card i {
            font-size: 2rem;
            margin-bottom: 10px;
            color: #4e73df;
        }
        
        .stats-card h3 {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .stats-card p {
            color: #6c757d;
            margin-bottom: 0;
        }
        
        .mobile-menu {
            display: none;
            background: linear-gradient(135deg, #4e73df, #224abe);
            padding: 15px;
            color: white;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                z-index: 1000;
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .mobile-menu {
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
        }
        
        /* Dark mode */
        .dark-mode {
            background-color: #1a1a1a;
            color: #f1f1f1;
        }
        
        .dark-mode .card,
        .dark-mode .welcome-banner {
            background-color: #2c2c2c;
            color: #f1f1f1;
        }
        
        .dark-mode .card-body {
            background-color: #2c2c2c;
            color: #f1f1f1;
        }
        
        .dark-mode .table {
            color: #f1f1f1;
            background-color: #2c2c2c;
        }
        
        .dark-mode .table-hover tbody tr:hover {
            background-color: #3c3c3c;
        }
        
        .dark-mode .bg-white {
            background-color: #2c2c2c !important;
            color: #f1f1f1;
        }
        
        .dark-mode footer.bg-white {
            background-color: #2c2c2c !important;
            color: #f1f1f1;
        }
        
        .dark-mode .text-gray-800 {
            color: #f1f1f1 !important;
        }
        
        #darkModeToggle {
            cursor: pointer;
        }
        
        .topbar-divider {
            width: 0;
            border-right: 1px solid #e3e6f0;
            height: 2rem;
            margin: auto 1rem;
        }
        
        .dropdown-header {
            font-weight: 600;
            font-size: 0.8rem;
            color: #b7b9cc;
            text-transform: uppercase;
        }
    </style>
</head>
<body id="page-top">
    <!-- Mobile Menu -->
    <div class="mobile-menu">
        <button class="btn" id="sidebarToggle">
            <i class="fas fa-bars text-white"></i>
        </button>
        <h5 class="mb-0">Fashion Store Admin</h5>
        <div>
            <i class="fas fa-moon text-white" id="darkModeToggle"></i>
        </div>
    </div>

    <!-- Page Wrapper -->
    <div id="wrapper">
        <!-- Sidebar -->
        <nav class="sidebar" id="sidebar">
            <div class="logo">
                <h4><i class="fas fa-laugh-wink rotate-n-15 me-2"></i> Fashion Store</h4>
            </div>
            <div class="mt-3">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link active" href="admin_dashboard.php">
                            <i class="fas fa-fw fa-tachometer-alt"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">
                            <i class="fas fa-fw fa-boxes"></i> Kelola Produk
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage_promos.php">
                            <i class="fas fa-fw fa-tags"></i> Kelola Promo
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="sales_report.php">
                            <i class="fas fa-fw fa-chart-bar"></i> Laporan Penjualan
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="low_stock_notification.php">
                            <i class="fas fa-fw fa-exclamation-triangle"></i> Notifikasi Stok
                        </a>
                    </li>
                    <li class="nav-item mt-3">
                        <a class="nav-link text-danger" href="logout.php">
                            <i class="fas fa-fw fa-sign-out-alt"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column main-content">
            <div id="content">
                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white mb-4 shadow-sm rounded">
                    <div class="container-fluid">
                        <h3 class="text-primary">Admin Dashboard</h3>
                        
                        <!-- Topbar Navbar -->
                        <ul class="navbar-nav ml-auto">
                            <div class="topbar-divider d-none d-sm-block"></div>
                            
                            <!-- Nav Item - User Information -->
                            <li class="nav-item dropdown no-arrow">
                                <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    <span class="d-none d-lg-inline text-gray-600 me-2">Admin</span>
                                    <i class="fas fa-user-circle fa-fw"></i>
                                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                        !
                                    </span>
                                </a>
                                <!-- Dropdown - User Information -->
                                <div class="dropdown-menu dropdown-menu-end shadow animated--grow-in" aria-labelledby="userDropdown">
                                    <a class="dropdown-item" href="profile.php">
                                        <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                        Profil Saya
                                    </a>
                                    <a class="dropdown-item" href="contact_support.php">
                                        <i class="fas fa-envelope fa-sm fa-fw mr-2 text-gray-400"></i>
                                        Hubungi Support
                                    </a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="user_guide.php">
                                        <i class="fas fa-book fa-sm fa-fw mr-2 text-gray-400"></i>
                                        Panduan Pengguna
                                    </a>
                                    <a class="dropdown-item text-danger" href="logout.php">
                                        <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-danger"></i>
                                        Logout
                                    </a>
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>

                <!-- Welcome Banner -->
                <div class="welcome-banner">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h2 class="mb-2">Selamat Datang, Admin!</h2>
                            <p class="mb-0">Pantau penjualan, stok, dan kelola produk dari satu tempat.</p>
                        </div>
                        <div class="col-md-4 text-md-end">
                            <button class="btn btn-light" onclick="window.location.href='sales_report.php'">
                                <i class="fas fa-chart-line me-2"></i>Lihat Laporan Lengkap
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Begin Page Content -->
                <div class="container-fluid px-0">
                    <!-- Stats Cards -->
                    <div class="row">
                        <!-- Pendapatan Hari Ini -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary h-100">
                                <div class="card-body">
                                    <div class="row align-items-center">
                                        <div class="col">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Pendapatan Hari Ini</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                Rp <?php echo number_format($total_sales_today, 0, ',', '.'); ?>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                      
                        
                        <!-- Produk Stok Rendah -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-warning h-100">
                                <div class="card-body">
                                    <div class="row align-items-center">
                                        <div class="col">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                Produk Stok Rendah</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                <?php echo count($low_stock_products); ?>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-exclamation-triangle fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Tombol Aksi Cepat -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body d-flex flex-wrap gap-2">
                                    <a href="create.php" class="btn btn-primary">
                                        <i class="fas fa-plus-circle me-2"></i>Tambah Produk Baru
                                    </a>
                                    <a href="export_orders.php" class="btn btn-success">
                                        <i class="fas fa-file-export me-2"></i>Export Data Pesanan
                                    </a>
                                    <a href="manage_promos.php" class="btn btn-info text-white">
                                        <i class="fas fa-tag me-2"></i>Kelola Promo
                                    </a>
                                    <a href="low_stock_notification.php" class="btn btn-warning text-white">
                                        <i class="fas fa-exclamation-circle me-2"></i>Lihat Stok Rendah
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Grafik Penjualan dan Notifikasi Stok Rendah -->
                    <div class="row">
                        <!-- Grafik Penjualan Bulanan -->
                        <div class="col-xl-8 col-lg-7">
                            <div class="card shadow mb-4">
                                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                                    <h6 class="m-0 font-weight-bold text-primary">Grafik Penjualan Bulanan</h6>
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                                            Periode
                                        </button>
                                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                            <li><a class="dropdown-item" href="#">Bulanan</a></li>
                                            <li><a class="dropdown-item" href="#">Triwulan</a></li>
                                            <li><a class="dropdown-item" href="#">Tahunan</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <canvas id="salesChart" style="height: 300px;"></canvas>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Notifikasi Stok Rendah -->
                        <div class="col-xl-4 col-lg-5">
                            <div class="card shadow mb-4">
                                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                                    <h6 class="m-0 font-weight-bold text-warning">Produk Stok Rendah</h6>
                                    <a href="low_stock_notification.php" class="btn btn-sm btn-warning text-white">
                                        Lihat Semua
                                    </a>
                                </div>
                                <div class="card-body">
                                    <div class="list-group">
                                        <?php foreach ($low_stock_products as $product): ?>
                                            <div class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                                                <div>
                                                    <h6 class="mb-1"><?php echo htmlspecialchars($product['name']); ?></h6>
                                                    <small class="text-danger">Stok: <?php echo $product['stock']; ?></small>
                                                </div>
                                                <a href="edit.php?id=<?php echo $product['id']; ?>" class="btn btn-sm btn-outline-primary">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                            </div>
                                        <?php endforeach; ?>
                                        <?php if (empty($low_stock_products)): ?>
                                            <div class="text-center py-3">
                                                <i class="fas fa-check-circle text-success fa-2x mb-3"></i>
                                                <p>Tidak ada produk dengan stok rendah</p>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Pesanan Terbaru -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3 d-flex justify-content-between align-items-center">
                            <h6 class="m-0 font-weight-bold text-primary">Pesanan Terbaru</h6>
                            <form method="GET" class="d-none d-sm-inline-block form-inline ml-md-3 my-2 my-md-0 w-50">
                                <div class="input-group">
                                    <input type="text" name="search" class="form-control bg-light border-0 small" placeholder="Cari pesanan..." aria-label="Search" aria-describedby="basic-addon2">
                                    <div class="input-group-append">
                                        <button class="btn btn-primary" type="submit">
                                            <i class="fas fa-search fa-sm"></i>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead>
                                        <tr>
                                            <th>ID Pesanan</th>
                                            <th>Tanggal Pesanan</th>
                                            <th>Total Harga</th>
                                            <th>Status</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($recent_orders as $order): ?>
                                            <tr>
                                                <td>#<?php echo htmlspecialchars($order['id']); ?></td>
                                                <td><?php echo htmlspecialchars($order['order_date']); ?></td>
                                                <td>Rp <?php echo number_format($order['total_amount'], 0, ',', '.'); ?></td>
                                                <td>
                                                    <?php 
                                                    $status = htmlspecialchars($order['status']);
                                                    $statusClass = '';
                                                    
                                                    switch ($status) {
                                                        case 'Pending':
                                                            $statusClass = 'status-pending';
                                                            break;
                                                        case 'Processing':
                                                            $statusClass = 'status-processing';
                                                            break;
                                                        case 'Shipped':
                                                            $statusClass = 'status-shipped';
                                                            break;
                                                        case 'Delivered':
                                                            $statusClass = 'status-delivered';
                                                            break;
                                                        case 'Cancelled':
                                                            $statusClass = 'status-cancelled';
                                                            break;
                                                        default:
                                                            $statusClass = 'status-pending';
                                                    }
                                                    ?>
                                                    <span class="status-badge <?php echo $statusClass; ?>"><?php echo $status; ?></span>
                                                </td>
                                                <td>
                                                    <a href="update_order.php?id=<?php echo htmlspecialchars($order['id']); ?>" class="btn btn-sm btn-primary">
                                                        <i class="fas fa-edit me-1"></i> Update
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                        <?php if (empty($recent_orders)): ?>
                                            <tr>
                                                <td colspan="5" class="text-center py-3">Tidak ada pesanan terbaru</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Footer -->
            <footer class="sticky-footer bg-white rounded shadow-sm mt-auto">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto py-3">
                        <span>Copyright &copy; Fashion Store 2023</span>
                    </div>
                </div>
            </footer>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JS -->
    <script>
        // Sidebar Toggle
        document.getElementById('sidebarToggle').addEventListener('click', function() {
            document.getElementById('sidebar').classList.toggle('active');
        });
        
        // Dark Mode Toggle
        document.getElementById('darkModeToggle').addEventListener('click', function() {
            document.body.classList.toggle('dark-mode');
            
            if (document.body.classList.contains('dark-mode')) {
                this.classList.remove('fa-moon');
                this.classList.add('fa-sun');
            } else {
                this.classList.remove('fa-sun');
                this.classList.add('fa-moon');
            }
        });
        
        // Chart.js Initialization
        const ctx = document.getElementById('salesChart').getContext('2d');
        const salesChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: [<?php echo "'" . implode("','", array_column($monthly_sales, 'month')) . "'"; ?>],
                datasets: [{
                    label: 'Total Penjualan (Rp)',
                    data: [<?php echo implode(',', array_column($monthly_sales, 'total_sales')); ?>],
                    backgroundColor: 'rgba(78, 115, 223, 0.2)',
                    borderColor: 'rgba(78, 115, 223, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
    </script>
</body>
</html>