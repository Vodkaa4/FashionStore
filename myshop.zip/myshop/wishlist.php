<?php
session_start();
include 'db.php';

// Redirect jika belum login atau bukan customer
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'customer') {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    $stmt = $conn->prepare("
        SELECT w.id AS wishlist_id, p.name AS product_name, p.image, p.price, w.created_at
        FROM wishlist w
        JOIN products p ON w.product_id = p.id
        WHERE w.user_id = :user_id
    ");
    $stmt->bindParam(':user_id', $user_id);
    $stmt->execute();
    $wishlist = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wishlist - Fashion Store</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>Wishlist</h1>

        <!-- Tombol Back -->
        <div class="mb-3">
            <a href="customer_dashboard.php" class="btn btn-secondary">Kembali</a>
        </div>

        <div class="row">
            <?php if (!empty($wishlist)): ?>
                <?php foreach ($wishlist as $item): ?>
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <img src="<?php echo htmlspecialchars($item['image']); ?>" class="card-img-top" alt="Gambar Produk">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($item['product_name']); ?></h5>
                                <p class="card-text">Rp <?php echo number_format($item['price'], 0, ',', '.'); ?></p>
                                <a href="remove_wishlist.php?id=<?php echo htmlspecialchars($item['wishlist_id']); ?>" class="btn btn-danger">Hapus</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Belum ada produk di wishlist.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>