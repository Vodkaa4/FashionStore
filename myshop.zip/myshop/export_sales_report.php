<?php
session_start();
include 'db.php';

// Cek apakah user sudah login sebagai admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];

try {
    // Query ringkasan penjualan
    $stmt = $conn->prepare("
        SELECT 
            DATE(order_date) AS order_date,
            COUNT(*) AS total_orders,
            SUM(total_amount) AS total_sales
        FROM orders
        WHERE DATE(order_date) BETWEEN :start_date AND :end_date
        GROUP BY DATE(order_date)
    ");
    $stmt->bindParam(':start_date', $start_date);
    $stmt->bindParam(':end_date', $end_date);
    $stmt->execute();
    $sales_summary = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Query detail produk terjual
    $stmt = $conn->prepare("
        SELECT 
            p.name AS product_name,
            od.quantity AS total_quantity,
            od.price AS unit_price,
            (od.quantity * od.price) AS total_revenue
        FROM order_details od
        JOIN products p ON od.product_id = p.id
        JOIN orders o ON od.order_id = o.id
        WHERE DATE(o.order_date) BETWEEN :start_date AND :end_date
    ");
    $stmt->bindParam(':start_date', $start_date);
    $stmt->bindParam(':end_date', $end_date);
    $stmt->execute();
    $product_details = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}

// Export to CSV
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="sales_report.csv"');

$output = fopen('php://output', 'w');

// Header untuk Ringkasan Penjualan
fputcsv($output, ['Tanggal', 'Total Pesanan', 'Total Pendapatan']);
foreach ($sales_summary as $summary) {
    fputcsv($output, [
        $summary['order_date'],
        $summary['total_orders'],
        $summary['total_sales']
    ]);
}

// Spacer
fputcsv($output, []);

// Header untuk Detail Produk Terjual
fputcsv($output, ['Nama Produk', 'Jumlah Terjual', 'Harga Satuan', 'Total Pendapatan']);
foreach ($product_details as $detail) {
    fputcsv($output, [
        $detail['product_name'],
        $detail['total_quantity'],
        $detail['unit_price'],
        $detail['total_revenue']
    ]);
}

fclose($output);
exit;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chart.js Example</title>
    <!-- Tambahkan Chart.js dari CDN -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <canvas id="myChart" width="400" height="200"></canvas>

    <script>
        // Contoh sederhana buat bikin grafik
        const ctx = document.getElementById('myChart').getContext('2d');
        const myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May'],
                datasets: [{
                    label: 'Penjualan',
                    data: [12, 19, 3, 5, 2],
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>