<?php
session_start();
include 'db.php';

// Redirect jika belum login atau bukan customer
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'customer') {
    header("Location: login.php");
    exit;
}

if (isset($_GET['id'])) {
    $wishlist_id = intval($_GET['id']);
    $user_id = $_SESSION['user_id'];

    try {
        // Hapus item dari wishlist
        $stmt = $conn->prepare("DELETE FROM wishlist WHERE id = :wishlist_id AND user_id = :user_id");
        $stmt->bindParam(':wishlist_id', $wishlist_id, PDO::PARAM_INT);
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->execute();

        header("Location: customer_dashboard.php");
        exit;
    } catch (PDOException $e) {
        die("Error: " . $e->getMessage());
    }
} else {
    die("ID wishlist tidak valid.");
}
?>