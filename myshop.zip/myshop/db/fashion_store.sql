-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 16, 2025 at 10:02 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fashion_store`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `product_id`, `quantity`, `created_at`) VALUES
(17, 5, 18, 1, '2025-02-16 15:34:03');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(3, 'Aksesoris'),
(1, 'Pakaian Pria'),
(2, 'Pakaian Wanita'),
(4, 'Sepatu');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_date` datetime DEFAULT current_timestamp(),
  `total_amount` decimal(10,2) NOT NULL,
  `status` enum('pending','processing','shipped','delivered') DEFAULT 'pending',
  `shipping_address` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `order_date`, `total_amount`, `status`, `shipping_address`) VALUES
(1, 5, '2025-02-16 11:19:08', 400000.00, 'pending', 'Alamat Pengiriman'),
(2, 5, '2025-02-16 11:21:35', 400000.00, 'pending', 'Alamat Pengiriman'),
(3, 5, '2025-02-16 11:31:20', 8000.00, 'pending', 'Alamat Pengiriman'),
(4, 5, '2025-02-16 13:50:12', 16799.90, 'pending', NULL),
(5, 5, '2025-02-16 13:59:55', 500000.00, 'pending', NULL),
(6, 5, '2025-02-16 14:19:33', 7000000.00, 'pending', NULL),
(7, 5, '2025-02-16 14:51:00', 4000000.00, 'pending', NULL),
(8, 5, '2025-02-16 15:25:17', 999.90, 'pending', NULL),
(9, 5, '2025-02-16 15:29:55', 4000000.00, 'pending', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`id`, `order_id`, `product_id`, `quantity`, `price`) VALUES
(1, 4, 3, 2, 8000.00),
(2, 4, 12, 1, 799.90),
(3, 5, 14, 1, 500000.00),
(4, 6, 12, 1, 7000000.00),
(5, 7, 17, 1, 4000000.00),
(6, 8, 15, 1, 999.90),
(7, 9, 17, 1, 4000000.00);

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `price`) VALUES
(3, 3, 3, 1, 8000.00);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `size` varchar(10) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `discount` decimal(5,2) DEFAULT 0.00,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `stock`, `category_id`, `size`, `color`, `image`, `discount`, `created_at`) VALUES
(3, 'Zara', 'Bahan polyster', 8000.00, 2, 2, 'M', 'Merah', 'uploads/resa90a10000563cc6903f56b373464a2cdfr.jpg', 0.00, '2025-02-15 11:43:40'),
(12, 'Blazer Optimus Zara', 'Collared, long-sleeved dress. Faded effect. Patch pockets on the front and back. Metal button fastening at the front.', 7000000.00, 8, 2, 'XL', 'Silver', 'uploads/01879021427-e1.jpg', 0.00, '2025-02-16 12:46:39'),
(13, 'Z1975 DENIM MINI DRESS', 'Long sleeve jumpsuit with a lapel collar. Front pockets and patch pockets on the back. Straight leg. Zip fly and metal button fastening.', 9999999.99, 7, 2, 'M', 'Silver', 'uploads/04365070420-e1.jpg', 0.00, '2025-02-16 13:54:27'),
(14, 'Top Satin Brazzer', 'Composition, care & origin\r\nCheck in-store availability\r\nSHIPPING, EXCHANGES AND RETURNS', 500000.00, 4, 2, 'S', 'Merah', 'uploads/02308651600-e1.jpg', 0.00, '2025-02-16 13:58:15'),
(15, 'RIBBED SHORT DRESS', 'Fitted short dress. Featuring a lapel collar, short sleeves and a ribbed trim. Godet hem and front button fastening in a polo style.', 999.90, 6, 2, 'M', 'Putih', 'uploads/08372054700-e1.jpg', 0.00, '2025-02-16 14:45:34'),
(16, 'BELTED MINI DRESS', 'Short two-piece effect dress. Boat neck and sleeveless. Mock welt pockets on the front. Contrast belt. Lining. Concealed side zip fastening.', 400000.00, 8, 2, 'XL', 'Hijau', 'uploads/02330896502-e1.jpg', 0.00, '2025-02-16 14:46:36'),
(17, 'Nike Zoom Air 3', 'My Zara Account\r\nItems and Sizes', 4000000.00, 1, 4, '32', 'Putih', 'uploads/W+NIKE+ZOOM+VOMERO+5.png', 0.00, '2025-02-16 14:48:08'),
(18, 'SHORT RUFFLED DRESS', 'Fitted boat neck dress with long sleeves and matching ruffle trim on the hem.', 30000000.00, 10, 2, 'M', 'Coklat', 'uploads/02132725401-e1.jpg', 0.00, '2025-02-16 14:50:12'),
(19, 'Knitwear Japan Tubo', 'achine wash at max. 30ºC/86ºF with short spin cycle', 500000.00, 16, 1, 'L', 'Hitam', 'uploads/06462433800-e1.jpg', 0.00, '2025-02-16 15:43:10');

-- --------------------------------------------------------

--
-- Table structure for table `promos`
--

CREATE TABLE `promos` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `discount` decimal(5,2) NOT NULL,
  `valid_from` date NOT NULL,
  `valid_to` date NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `promos`
--

INSERT INTO `promos` (`id`, `code`, `description`, `discount`, `valid_from`, `valid_to`, `created_at`) VALUES
(5, 'K33', 'Spesial Hari Raya Idul FItri', 80.00, '2025-02-14', '2025-02-22', '2025-02-16 11:08:47'),
(6, 'F55', 'Spesial Valentine', 40.00, '2025-02-14', '2025-02-28', '2025-02-16 11:09:14');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `comment` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','customer') NOT NULL,
  `email` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `email`, `created_at`) VALUES
(1, 'Vodka', '$2y$10$/QxbcVxFT/hvOzZpXYotUeonqaeVjtgTvJYqpH/LIXU7n2SZgi7Hm', 'customer', 'jaddlyn@gmail.com', '2025-02-15 10:45:45'),
(2, 'admin123', '123', 'admin', 'admin@example.com', '2025-02-15 10:54:07'),
(3, 'admin', '123456', 'admin', '', '2025-02-15 10:56:28'),
(4, 'alif', '$2y$10$10emadHZhU9masgINBN3qOsopo0AvGeLGxqUjj9t8PRxkm9xFaMx2', 'admin', 'coldh4rtd@gmail.com', '2025-02-15 11:00:34'),
(5, 'ahmad', '$2y$10$iqpWOyPvL5b.mQ2sTwIvw.tk4icut56F6g1U7Q5kJ/ss.KVL9/o1e', 'customer', 'ahmad@gmail.com', '2025-02-15 13:35:47'),
(6, 'demas', '$2y$10$bDNKgPInkjjf3.W8OcMvXOeb.Vm.IImyRGY8hsNYKYF1umanOeXuG', 'admin', 'demas@gmail.com', '2025-02-15 14:29:42'),
(7, 'paruq', '$2y$10$NZHvzVXihlukOh3nAjZnnOxQF9kkngqQEtO2KM4yqCKFXyu4kjRhe', 'customer', 'paruq@gmail.com', '2025-02-15 18:05:10'),
(8, 'vvod', '$2y$10$snOezeo6bmIjQGExESs8l.CxpNfYQ4Le8oHLPtBaEg8rNPzzq9/mC', 'admin', 'vvod@gmail.com', '2025-02-16 12:05:46'),
(9, 'koko', '$2y$10$ypFR54rPCwA8NVfVMCNX..nEW7ivv9acAvPacdTTqQMdd3ztIwe7K', 'customer', 'koko@gmail.com', '2025-02-16 14:15:49');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`id`, `user_id`, `product_id`, `created_at`) VALUES
(8, 5, 12, '2025-02-16 13:42:50'),
(9, 5, 18, '2025-02-16 14:52:50'),
(10, 5, 16, '2025-02-16 14:52:53');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `promos`
--
ALTER TABLE `promos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `wishlist_ibfk_2` (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `promos`
--
ALTER TABLE `promos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `order_details`
--
ALTER TABLE `order_details`
  ADD CONSTRAINT `order_details_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  ADD CONSTRAINT `order_details_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD CONSTRAINT `wishlist_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `wishlist_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
