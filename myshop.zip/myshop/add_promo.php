<?php
session_start();
include 'db.php';

// Cek apakah user sudah login sebagai admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $code = trim($_POST['code']);
    $description = trim($_POST['description']);
    $discount = $_POST['discount'];
    $valid_from = $_POST['valid_from'];
    $valid_to = $_POST['valid_to'];

    // Validasi input
    if (empty($code) || empty($description) || empty($discount) || empty($valid_from) || empty($valid_to)) {
        $error = "Semua field wajib diisi.";
    } elseif ($discount <= 0 || $discount > 100) {
        $error = "Diskon harus antara 1% sampai 100%.";
    } else {
        try {
            // Simpan data ke database
            $stmt = $conn->prepare("INSERT INTO promos (code, description, discount, valid_from, valid_to) VALUES (:code, :description, :discount, :valid_from, :valid_to)");
            $stmt->bindParam(':code', $code);
            $stmt->bindParam(':description', $description);
            $stmt->bindParam(':discount', $discount);
            $stmt->bindParam(':valid_from', $valid_from);
            $stmt->bindParam(':valid_to', $valid_to);

            if ($stmt->execute()) {
                $success = "Promo berhasil ditambahkan!";
            } else {
                $error = "Gagal menambahkan promo.";
            }
        } catch (PDOException $e) {
            $error = "Error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Promo - Fashion Store</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Tambah Promo Baru</h1>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-3">
                <label for="code" class="form-label">Kode Promo:</label>
                <input type="text" class="form-control" name="code" required>
            </div>
            <div class="mb-3">
                <label for="description" class="form-label">Deskripsi:</label>
                <textarea class="form-control" name="description" required></textarea>
            </div>
            <div class="mb-3">
                <label for="discount" class="form-label">Diskon (%):</label>
                <input type="number" step="0.01" class="form-control" name="discount" min="1" max="100" required>
            </div>
            <div class="mb-3">
                <label for="valid_from" class="form-label">Berlaku Dari:</label>
                <input type="date" class="form-control" name="valid_from" required>
            </div>
            <div class="mb-3">
                <label for="valid_to" class="form-label">Berlaku Sampai:</label>
                <input type="date" class="form-control" name="valid_to" required>
            </div>
            <button type="submit" class="btn btn-primary">Simpan Promo</button>
            <a href="manage_promos.php" class="btn btn-secondary">Kembali</a>
        </form>
    </div>
</body>
</html>