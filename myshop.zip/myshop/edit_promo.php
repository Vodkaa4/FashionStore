<?php
session_start();
include 'db.php';

// Cek apakah user sudah login sebagai admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

// Inisialisasi variabel error
$error = '';
$promo = [];

$id = $_GET['id'] ?? null;

if (!$id) {
    die("ID promo tidak ditemukan.");
}

try {
    // Ambil data promo
    $stmt = $conn->prepare("SELECT * FROM promos WHERE id = :id");
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    $promo = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$promo) {
        die("Promo tidak ditemukan.");
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $code = trim($_POST['code']);
        $description = trim($_POST['description']);
        $discount = $_POST['discount'];
        $valid_from = $_POST['valid_from'];
        $valid_to = $_POST['valid_to'];

        // Validasi input
        if (empty($code) || empty($description) || empty($discount) || empty($valid_from) || empty($valid_to)) {
            $error = "Semua field wajib diisi.";
        } elseif ($discount <= 0 || $discount > 100) {
            $error = "Diskon harus antara 1% sampai 100%.";
        } else {
            // Update data promo
            $update_stmt = $conn->prepare("UPDATE promos SET code = :code, description = :description, discount = :discount, valid_from = :valid_from, valid_to = :valid_to WHERE id = :id");
            $update_stmt->bindParam(':code', $code);
            $update_stmt->bindParam(':description', $description);
            $update_stmt->bindParam(':discount', $discount);
            $update_stmt->bindParam(':valid_from', $valid_from);
            $update_stmt->bindParam(':valid_to', $valid_to);
            $update_stmt->bindParam(':id', $id);

            if ($update_stmt->execute()) {
                header("Location: manage_promos.php?success=Promo berhasil diperbarui!");
                exit;
            } else {
                $error = "Gagal memperbarui promo.";
            }
        }
    }
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Promo - Fashion Store</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Edit Promo</h1>

        <!-- Tombol Back -->
        <div class="mb-3 text-start">
            <a href="admin_dashboard.php" class="btn btn-secondary">Back to Admin Dashboard</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-3">
                <label for="code" class="form-label">Kode Promo:</label>
                <input type="text" class="form-control" name="code" value="<?php echo htmlspecialchars($promo['code'] ?? ''); ?>" required>
            </div>
            <div class="mb-3">
                <label for="description" class="form-label">Deskripsi:</label>
                <textarea class="form-control" name="description" required><?php echo htmlspecialchars($promo['description'] ?? ''); ?></textarea>
            </div>
            <div class="mb-3">
                <label for="discount" class="form-label">Diskon (%):</label>
                <input type="number" step="0.01" class="form-control" name="discount" value="<?php echo htmlspecialchars($promo['discount'] ?? ''); ?>" min="1" max="100" required>
            </div>
            <div class="mb-3">
                <label for="valid_from" class="form-label">Berlaku Dari:</label>
                <input type="date" class="form-control" name="valid_from" value="<?php echo htmlspecialchars($promo['valid_from'] ?? ''); ?>" required>
            </div>
            <div class="mb-3">
                <label for="valid_to" class="form-label">Berlaku Sampai:</label>
                <input type="date" class="form-control" name="valid_to" value="<?php echo htmlspecialchars($promo['valid_to'] ?? ''); ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
            <a href="manage_promos.php" class="btn btn-secondary">Kembali ke Kelola Promo</a>
        </form>
    </div>
</body>
</html>