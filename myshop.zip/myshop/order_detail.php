<?php
session_start();
include 'db.php';

// Redirect jika belum login atau bukan customer
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'customer') {
    header("Location: login.php");
    exit;
}

$order_id = isset($_GET['id']) ? intval($_GET['id']) : null;

if (!$order_id) {
    die("ID pesanan tidak valid.");
}

try {
    // Ambil data pesanan
    $order_stmt = $conn->prepare("
        SELECT id, total_amount, status, order_date
        FROM orders
        WHERE id = :order_id AND user_id = :user_id
    ");
    $order_stmt->bindParam(':order_id', $order_id, PDO::PARAM_INT);
    $order_stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
    $order_stmt->execute();
    $order = $order_stmt->fetch(PDO::FETCH_ASSOC);

    if (!$order) {
        die("Pesanan tidak ditemukan.");
    }

    // Ambil detail pesanan
    $details_stmt = $conn->prepare("
        SELECT od.quantity, od.price, p.name, p.image
        FROM order_details od
        JOIN products p ON od.product_id = p.id
        WHERE od.order_id = :order_id
    ");
    $details_stmt->bindParam(':order_id', $order_id, PDO::PARAM_INT);
    $details_stmt->execute();
    $order_details = $details_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Pesanan - Fashion Store</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Detail Pesanan</h1>

        <!-- Informasi Pesanan -->
        <div class="card mb-4">
            <div class="card-body">
                <h5 class="card-title">Informasi Pesanan</h5>
                <p><strong>ID Pesanan:</strong> <?php echo htmlspecialchars($order['id']); ?></p>
                <p><strong>Tanggal Pesanan:</strong> <?php echo htmlspecialchars($order['order_date']); ?></p>
                <p><strong>Total Harga:</strong> Rp <?php echo number_format($order['total_amount'], 0, ',', '.'); ?></p>
                <p><strong>Status:</strong> <?php echo htmlspecialchars($order['status']); ?></p>
            </div>
        </div>

        <!-- Detail Produk -->
        <h2>Detail Produk</h2>
        <table class="table table-bordered table-hover">
            <thead class="table-dark">
                <tr>
                    <th>Gambar</th>
                    <th>Nama Produk</th>
                    <th>Harga</th>
                    <th>Jumlah</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($order_details)): ?>
                    <?php foreach ($order_details as $detail): ?>
                        <tr>
                            <td>
                                <img src="<?php echo htmlspecialchars($detail['image']); ?>" alt="Gambar Produk" style="width: 50px; height: 50px; object-fit: cover;">
                            </td>
                            <td><?php echo htmlspecialchars($detail['name']); ?></td>
                            <td>Rp <?php echo number_format($detail['price'], 0, ',', '.'); ?></td>
                            <td><?php echo htmlspecialchars($detail['quantity']); ?></td>
                            <td>Rp <?php echo number_format($detail['price'] * $detail['quantity'], 0, ',', '.'); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" class="text-center">Tidak ada detail pesanan.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <!-- Tombol Back -->
        <div class="text-end">
            <a href="customer_dashboard.php" class="btn btn-secondary">Kembali</a>
        </div>
    </div>
</body>
</html>