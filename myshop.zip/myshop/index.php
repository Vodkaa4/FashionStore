<?php
session_start();
include 'db.php';

// Redirect ke halaman login kalo user belum login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Ambil semua kategori untuk dropdown filter
try {
    $category_stmt = $conn->prepare("SELECT * FROM categories");
    $category_stmt->execute();
    $categories = $category_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}

// Query dasar untuk mengambil produk
$query = "SELECT * FROM products WHERE 1=1";

// Filter berdasarkan kategori
if (isset($_GET['category']) && !empty($_GET['category'])) {
    $category_id = intval($_GET['category']); // Pastiin input aman
    $query .= " AND category_id = :category_id";
}

// Filter berdasarkan ukuran
if (isset($_GET['size']) && !empty($_GET['size'])) {
    $size = trim($_GET['size']);
    $query .= " AND size LIKE :size";
}

// Filter berdasarkan warna
if (isset($_GET['color']) && !empty($_GET['color'])) {
    $color = trim($_GET['color']);
    $query .= " AND color LIKE :color";
}

// Eksekusi query
try {
    $stmt = $conn->prepare($query);

    if (isset($_GET['category']) && !empty($_GET['category'])) {
        $stmt->bindParam(':category_id', $category_id, PDO::PARAM_INT);
    }
    if (isset($_GET['size']) && !empty($_GET['size'])) {
        $size = "%{$_GET['size']}%";
        $stmt->bindParam(':size', $size, PDO::PARAM_STR);
    }
    if (isset($_GET['color']) && !empty($_GET['color'])) {
        $color = "%{$_GET['color']}%";
        $stmt->bindParam(':color', $color, PDO::PARAM_STR);
    }

    $stmt->execute();
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Produk - Fashion Store</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="text-center">Daftar Produk Fashion Store</h1>
            <a href="admin_dashboard.php" class="btn btn-secondary">⬅ Kembali ke Dashboard Admin</a>
        </div>

        <!-- Form Filter -->
        <form method="GET" class="mb-4">
            <div class="row">
                <div class="col-md-4">
                    <label for="category" class="form-label">Kategori:</label>
                    <select class="form-select" name="category">
                        <option value="">Semua Kategori</option>
                        <?php foreach ($categories as $category): ?>
                            <option value="<?php echo $category['id']; ?>" <?php echo (isset($_GET['category']) && $_GET['category'] == $category['id']) ? 'selected' : ''; ?>>
                                <?php echo $category['name']; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label for="size" class="form-label">Ukuran:</label>
                    <input type="text" class="form-control" name="size" placeholder="S, M, L, XL" value="<?php echo isset($_GET['size']) ? htmlspecialchars($_GET['size']) : ''; ?>">
                </div>
                <div class="col-md-4">
                    <label for="color" class="form-label">Warna:</label>
                    <input type="text" class="form-control" name="color" placeholder="Hitam, Putih, Merah" value="<?php echo isset($_GET['color']) ? htmlspecialchars($_GET['color']) : ''; ?>">
                </div>
            </div>
            <button type="submit" class="btn btn-primary mt-3">Filter</button>
        </form>

        <!-- Daftar Produk -->
        <div class="row">
            <?php if (!empty($products)): ?>
                <?php foreach ($products as $product): ?>
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <img src="<?php echo htmlspecialchars($product['image']); ?>" class="card-img-top" alt="Gambar Produk" style="height: 200px; object-fit: cover;">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($product['name']); ?></h5>
                                <p class="card-text"><?php echo htmlspecialchars($product['description']); ?></p>
                                <p><strong>Harga:</strong> Rp <?php echo number_format($product['price'], 0, ',', '.'); ?></p>
                                <p><strong>Stok:</strong> <?php echo htmlspecialchars($product['stock']); ?></p>
                                <p><strong>Ukuran:</strong> <?php echo htmlspecialchars($product['size']); ?></p>
                                <p><strong>Warna:</strong> <?php echo htmlspecialchars($product['color']); ?></p>
                                
                                <!-- Tombol Aksi -->
                                <div class="d-flex gap-2">
                               <!-- <a href="add_to_wishlist.php?product_id=<?php echo $product['id']; ?>" class="btn btn-outline-danger">Tambah ke Wishlist</a>-->
                                    <a href="product_detail.php?id=<?php echo $product['id']; ?>" class="btn btn-primary btn-sm">Lihat Detail</a>
                                    <a href="edit.php?id=<?php echo $product['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <a href="delete.php?id=<?php echo $product['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin mau hapus produk ini?');">Hapus</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p class="text-center">Tidak ada produk yang tersedia.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>s