<?php
session_start();
include 'db.php';

// Redirect jika belum login atau bukan customer
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'customer') {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    // Ambil data keranjang customer
    $stmt = $conn->prepare("
        SELECT c.id AS cart_id, p.id AS product_id, p.name, p.price, p.stock, c.quantity
        FROM cart c
        JOIN products p ON c.product_id = p.id
        WHERE c.user_id = :user_id
    ");
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $cart_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($cart_items)) {
        // Redirect balik ke halaman keranjang dengan pesan error
        header("Location: cart.php?error=Keranjang%20belanja%20kosong.");
        exit;
    }

    // Mulai transaksi
    $conn->beginTransaction();

    // Hitung total harga dari keranjang
    $total_amount = 0;
    foreach ($cart_items as $item) {
        $total_amount += $item['price'] * $item['quantity'];
    }

    // Simpan data pesanan ke tabel orders
    $order_stmt = $conn->prepare("
        INSERT INTO orders (user_id, total_amount, status)
        VALUES (:user_id, :total_amount, 'Pending')
    ");
    $order_stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $order_stmt->bindParam(':total_amount', $total_amount, PDO::PARAM_STR);
    $order_stmt->execute();
    $order_id = $conn->lastInsertId();

    // Simpan detail pesanan ke tabel order_details
    foreach ($cart_items as $item) {
        $order_detail_stmt = $conn->prepare("
            INSERT INTO order_details (order_id, product_id, quantity, price)
            VALUES (:order_id, :product_id, :quantity, :price)
        ");
        $order_detail_stmt->bindParam(':order_id', $order_id, PDO::PARAM_INT);
        $order_detail_stmt->bindParam(':product_id', $item['product_id'], PDO::PARAM_INT);
        $order_detail_stmt->bindParam(':quantity', $item['quantity'], PDO::PARAM_INT);
        $order_detail_stmt->bindParam(':price', $item['price'], PDO::PARAM_STR);
        $order_detail_stmt->execute();

        // Kurangi stok produk
        $update_stock_stmt = $conn->prepare("
            UPDATE products SET stock = stock - :quantity WHERE id = :product_id
        ");
        $update_stock_stmt->bindParam(':quantity', $item['quantity'], PDO::PARAM_INT);
        $update_stock_stmt->bindParam(':product_id', $item['product_id'], PDO::PARAM_INT);
        $update_stock_stmt->execute();
    }

    // Hapus data keranjang
    $clear_cart_stmt = $conn->prepare("DELETE FROM cart WHERE user_id = :user_id");
    $clear_cart_stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $clear_cart_stmt->execute();

    // Commit transaksi
    $conn->commit();

    // Redirect ke halaman konfirmasi pesanan
    header("Location: order_confirmation.php");
    exit;
} catch (PDOException $e) {
    // Rollback transaksi kalo ada error
    $conn->rollBack();
    die("Error: " . $e->getMessage());
}
?>