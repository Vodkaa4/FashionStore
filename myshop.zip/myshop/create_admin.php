<?php
include 'db.php';

// Data admin
$username = 'admin123';
$email = 'admin@example.com';
$password = '1234'; // Ganti dengan password yang lo inginkan
$role = 'admin';

// Hash password
$hashed_password = password_hash($password, PASSWORD_BCRYPT);

try {
    // Insert data admin ke database
    $stmt = $conn->prepare("INSERT INTO users (username, password, role, email) VALUES (:username, :password, :role, :email)");
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':password', $hashed_password);
    $stmt->bindParam(':role', $role);
    $stmt->bindParam(':email', $email);

    if ($stmt->execute()) {
        echo "Akun admin berhasil dibuat!";
    } else {
        echo "Gagal membuat akun admin.";
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>