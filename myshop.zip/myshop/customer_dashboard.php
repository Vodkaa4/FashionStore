<?php
session_start();
include 'db.php';

// Redirect jika belum login atau bukan customer
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'customer') {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    // Ambil data user dari database
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = :id");
    $stmt->bindParam(':id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        die("User tidak ditemukan.");
    }

    // Ambil semua pesanan user
    $order_stmt = $conn->prepare("SELECT * FROM orders WHERE user_id = :user_id ORDER BY order_date DESC LIMIT 5");
    $order_stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $order_stmt->execute();
    $orders = $order_stmt->fetchAll(PDO::FETCH_ASSOC);

    // Ambil produk wishlist (contoh)
    $wishlist_stmt = $conn->prepare("SELECT * FROM wishlist WHERE user_id = :user_id LIMIT 3");
    $wishlist_stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $wishlist_stmt->execute();
    $wishlist = $wishlist_stmt->fetchAll(PDO::FETCH_ASSOC);

    // Ambil keranjang belanja (contoh)
    $cart_stmt = $conn->prepare("SELECT * FROM cart WHERE user_id = :user_id LIMIT 3");
    $cart_stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $cart_stmt->execute();
    $cart = $cart_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Dashboard - Fashion Store</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <style>
        body { 
            background-color: #f8f9fa; 
            font-family: 'Poppins', sans-serif;
        }
        
        .sidebar { 
            background-color: #2c3e50; 
            height: 100vh;
            position: fixed;
            width: 250px;
            transition: all 0.3s;
        }
        
        .sidebar .logo {
            padding: 20px 15px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar .logo h4 {
            color: #fff;
            margin-bottom: 0;
        }
        
        .sidebar a { 
            text-decoration: none; 
            color: #ecf0f1; 
            transition: all 0.3s ease;
            padding: 12px 20px;
            display: block;
        }
        
        .sidebar a:hover, 
        .sidebar a.active { 
            background-color: #34495e;
            border-left: 4px solid #3498db;
        }
        
        .sidebar .fas, 
        .sidebar .fa-solid {
            width: 25px;
            text-align: center;
            margin-right: 10px;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px 30px;
            transition: all 0.3s;
        }
        
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
            border: none;
            margin-bottom: 20px;
        }
        
        .card:hover {
            transform: translateY(-5px);
        }
        
        .card-profile {
            border-left: 5px solid #3498db;
        }
        
        .btn-primary {
            background-color: #3498db;
            border-color: #3498db;
        }
        
        .btn-primary:hover {
            background-color: #2980b9;
            border-color: #2980b9;
        }
        
        .btn-wishlist {
            background-color: #e74c3c;
            border-color: #e74c3c;
            color: white;
        }
        
        .btn-wishlist:hover {
            background-color: #c0392b;
            border-color: #c0392b;
        }
        
        .table {
            border-radius: 10px;
            overflow: hidden;
        }
        
        .table thead {
            background-color: #3498db;
            color: white;
        }
        
        .table-hover tbody tr:hover {
            background-color: #eaf2f8;
        }
        
        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 500;
        }
        
        .status-pending {
            background-color: #f39c12;
            color: white;
        }
        
        .status-processing {
            background-color: #3498db;
            color: white;
        }
        
        .status-shipped {
            background-color: #2ecc71;
            color: white;
        }
        
        .status-delivered {
            background-color: #27ae60;
            color: white;
        }
        
        .status-cancelled {
            background-color: #e74c3c;
            color: white;
        }
        
        .welcome-banner {
            background: linear-gradient(135deg, #3498db, #2c3e50);
            color: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .stats-card {
            text-align: center;
            padding: 20px;
        }
        
        .stats-card i {
            font-size: 2rem;
            margin-bottom: 10px;
            color: #3498db;
        }
        
        .stats-card h3 {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .stats-card p {
            color: #7f8c8d;
            margin-bottom: 0;
        }
        
        .mobile-menu {
            display: none;
            background-color: #2c3e50;
            padding: 15px;
            color: white;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                z-index: 1000;
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .mobile-menu {
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
        }
        
        /* Dark mode */
        .dark-mode {
            background-color: #1a1a1a;
            color: #f1f1f1;
        }
        
        .dark-mode .card,
        .dark-mode .welcome-banner {
            background-color: #2c2c2c;
            color: #f1f1f1;
        }
        
        .dark-mode .table {
            color: #f1f1f1;
            background-color: #2c2c2c;
        }
        
        .dark-mode .table-hover tbody tr:hover {
            background-color: #3c3c3c;
        }
        
        #darkModeToggle {
            cursor: pointer;
        }
    </style>
</head>
<body>
    <!-- Mobile Menu -->
    <div class="mobile-menu">
        <button class="btn" id="sidebarToggle">
            <i class="fas fa-bars text-white"></i>
        </button>
        <h5 class="mb-0">Fashion Store</h5>
        <div>
            <i class="fas fa-moon text-white" id="darkModeToggle"></i>
        </div>
    </div>

    <!-- Main Container -->
    <div class="container-fluid p-0">
        <div class="row g-0">
            <!-- Sidebar -->
            <nav class="col-md-3 col-lg-2 sidebar" id="sidebar">
                <div class="logo">
                    <h4><i class="fas fa-tshirt me-2"></i> Fashion Store</h4>
                </div>
                <div class="mt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="customer_dashboard.php">
                                <i class="fas fa-tachometer-alt"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="edit_profil.php">
                                <i class="fas fa-user-circle"></i> Edit Profil
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="wishlist.php">
                                <i class="fas fa-heart"></i> Wishlist
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="cart.php">
                                <i class="fas fa-shopping-cart"></i> Keranjang
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="products.php">
                                <i class="fas fa-box"></i> Order Produk
                            </a>
                        </li>
                        <li class="nav-item mt-3">
                            <a class="nav-link text-danger" href="logout.php">
                                <i class="fas fa-sign-out-alt"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main Content -->
            <main class="col-md-9 col-lg-10 main-content">
                <!-- Welcome Banner -->
                <div class="welcome-banner">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h1 class="mb-2">Selamat Datang, <?php echo htmlspecialchars($user['username']); ?>!</h1>
                            <p class="mb-0">Pantau pesanan, wishlist, dan akun Anda di satu tempat.</p>
                        </div>
                        <div class="col-md-4 text-md-end">
                            <button class="btn btn-light" onclick="window.location.href='products.php'">
                                <i class="fas fa-shopping-bag me-2"></i>Belanja Sekarang
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Stats Cards -->
                <div class="row mb-4">
                    <div class="col-md-3">
                        <div class="card stats-card">
                            <i class="fas fa-box"></i>
                            <h3>5</h3>
                            <p>Total Pesanan</p>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stats-card">
                            <i class="fas fa-heart"></i>
                            <h3>12</h3>
                            <p>Wishlist</p>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stats-card">
                            <i class="fas fa-shopping-cart"></i>
                            <h3>3</h3>
                            <p>Keranjang</p>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stats-card">
                            <i class="fas fa-truck"></i>
                            <h3>2</h3>
                            <p>Pesanan Aktif</p>
                        </div>
                    </div>
                </div>

                <!-- Order History -->
                <div class="card mb-4">
                    <div class="card-header bg-white d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><i class="fas fa-history me-2 text-primary"></i>Riwayat Pesanan Terbaru</h5>
                        <button class="btn btn-sm btn-outline-primary" onclick="window.location.href='all_orders.php'">
                            Lihat Semua
                        </button>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead>
                                    <tr>
                                        <th>ID Pesanan</th>
                                        <th>Tanggal Pesanan</th>
                                        <th>Total Harga</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (!empty($orders)): ?>
                                        <?php foreach ($orders as $order): ?>
                                            <tr>
                                                <td>#<?php echo htmlspecialchars($order['id']); ?></td>
                                                <td><?php echo htmlspecialchars($order['order_date']); ?></td>
                                                <td>Rp <?php echo number_format($order['total_amount'], 0, ',', '.'); ?></td>
                                                <td>
                                                    <?php 
                                                    $status = htmlspecialchars($order['status']);
                                                    $statusClass = '';
                                                    
                                                    switch ($status) {
                                                        case 'Pending':
                                                            $statusClass = 'status-pending';
                                                            break;
                                                        case 'Processing':
                                                            $statusClass = 'status-processing';
                                                            break;
                                                        case 'Shipped':
                                                            $statusClass = 'status-shipped';
                                                            break;
                                                        case 'Delivered':
                                                            $statusClass = 'status-delivered';
                                                            break;
                                                        case 'Cancelled':
                                                            $statusClass = 'status-cancelled';
                                                            break;
                                                        default:
                                                            $statusClass = 'status-pending';
                                                    }
                                                    ?>
                                                    <span class="status-badge <?php echo $statusClass; ?>"><?php echo $status; ?></span>
                                                </td>
                                                <td>
                                                    <a href="order_detail.php?id=<?php echo htmlspecialchars($order['id']); ?>" class="btn btn-sm btn-primary">
                                                        <i class="fas fa-eye me-1"></i> Detail
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="5" class="text-center py-3">Belum ada pesanan.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Activity Timeline -->
                <div class="row">
                    <div class="col-md-6 mb-4">
                        <div class="card h-100">
                            <div class="card-header bg-white">
                                <h5 class="mb-0"><i class="fas fa-calendar-alt me-2 text-primary"></i>Aktivitas Terbaru</h5>
                            </div>
                            <div class="card-body">
                                <div class="timeline">
                                    <div class="timeline-item mb-3 pb-3 border-bottom">
                                        <div class="d-flex">
                                            <div class="me-3">
                                                <i class="fas fa-shopping-bag text-primary"></i>
                                            </div>
                                            <div>
                                                <p class="mb-1 fw-bold">Pesanan #12345 dikirim</p>
                                                <p class="text-muted small mb-0">10 menit yang lalu</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="timeline-item mb-3 pb-3 border-bottom">
                                        <div class="d-flex">
                                            <div class="me-3">
                                                <i class="fas fa-heart text-danger"></i>
                                            </div>
                                            <div>
                                                <p class="mb-1 fw-bold">Menambahkan produk ke wishlist</p>
                                                <p class="text-muted small mb-0">3 jam yang lalu</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="timeline-item mb-3 pb-3 border-bottom">
                                        <div class="d-flex">
                                            <div class="me-3">
                                                <i class="fas fa-user-edit text-success"></i>
                                            </div>
                                            <div>
                                                <p class="mb-1 fw-bold">Memperbarui profil</p>
                                                <p class="text-muted small mb-0">Kemarin, 15:30</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Quick Actions -->
                    <div class="col-md-6 mb-4">
                        <div class="card h-100">
                            <div class="card-header bg-white">
                                <h5 class="mb-0"><i class="fas fa-bolt me-2 text-primary"></i>Aksi Cepat</h5>
                            </div>
                            <div class="card-body">
                                <div class="row g-3">
                                    <div class="col-6">
                                        <a href="cart.php" class="btn btn-light w-100 text-start p-3">
                                            <i class="fas fa-shopping-cart text-primary me-2"></i>
                                            Lihat Keranjang
                                        </a>
                                    </div>
                                    <div class="col-6">
                                        <a href="wishlist.php" class="btn btn-light w-100 text-start p-3">
                                            <i class="fas fa-heart text-danger me-2"></i>
                                            Lihat Wishlist
                                        </a>
                                    </div>
                                    <div class="col-6">
                                        <a href="edit_profil.php" class="btn btn-light w-100 text-start p-3">
                                            <i class="fas fa-user-edit text-success me-2"></i>
                                            Edit Profil
                                        </a>
                                    </div>
                                    <div class="col-6">
                                        <a href="products.php" class="btn btn-light w-100 text-start p-3">
                                            <i class="fas fa-store text-warning me-2"></i>
                                            Belanja Sekarang
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JS -->
    <script>
        // Sidebar Toggle
        document.getElementById('sidebarToggle').addEventListener('click', function() {
            document.getElementById('sidebar').classList.toggle('active');
        });
        
        // Dark Mode Toggle
        document.getElementById('darkModeToggle').addEventListener('click', function() {
            document.body.classList.toggle('dark-mode');
            
            if (document.body.classList.contains('dark-mode')) {
                this.classList.remove('fa-moon');
                this.classList.add('fa-sun');
            } else {
                this.classList.remove('fa-sun');
                this.classList.add('fa-moon');
            }
        });
    </script>
</body>
</html>